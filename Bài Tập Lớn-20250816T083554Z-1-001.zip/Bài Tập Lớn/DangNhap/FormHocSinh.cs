﻿namespace DangNhap
{
    internal class FormHocSinh
    {
        private string text;

        public FormHocSinh(string text)
        {
            this.text = text;
        }
    }
}