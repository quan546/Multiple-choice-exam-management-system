﻿namespace DangNhapGiaoVien
{
    partial class FormGiaoVienDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnQuanLyHocSinh = new System.Windows.Forms.Button();
            this.btnQuanLyBaiThi = new System.Windows.Forms.Button();
            this.btnQuanLyCauHoi = new System.Windows.Forms.Button();
            this.btnDangXuat = new System.Windows.Forms.Button();
            this.btnXemThongTinGiaoVien = new System.Windows.Forms.GroupBox();
            this.btnDoiMatKhau = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnXemThongTinGiaoVien.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnQuanLyHocSinh
            // 
            this.btnQuanLyHocSinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnQuanLyHocSinh.Location = new System.Drawing.Point(34, 108);
            this.btnQuanLyHocSinh.Name = "btnQuanLyHocSinh";
            this.btnQuanLyHocSinh.Size = new System.Drawing.Size(231, 47);
            this.btnQuanLyHocSinh.TabIndex = 1;
            this.btnQuanLyHocSinh.Text = "Quản Lý Học Sinh";
            this.btnQuanLyHocSinh.UseVisualStyleBackColor = true;
            this.btnQuanLyHocSinh.Click += new System.EventHandler(this.btnQuanLyHocSinh_Click);
            // 
            // btnQuanLyBaiThi
            // 
            this.btnQuanLyBaiThi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnQuanLyBaiThi.Location = new System.Drawing.Point(34, 280);
            this.btnQuanLyBaiThi.Name = "btnQuanLyBaiThi";
            this.btnQuanLyBaiThi.Size = new System.Drawing.Size(231, 47);
            this.btnQuanLyBaiThi.TabIndex = 2;
            this.btnQuanLyBaiThi.Text = "Quản Lý Bài Thi";
            this.btnQuanLyBaiThi.UseVisualStyleBackColor = true;
            this.btnQuanLyBaiThi.Click += new System.EventHandler(this.btnQuanLyBaiThi_Click);
            // 
            // btnQuanLyCauHoi
            // 
            this.btnQuanLyCauHoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnQuanLyCauHoi.Location = new System.Drawing.Point(34, 197);
            this.btnQuanLyCauHoi.Name = "btnQuanLyCauHoi";
            this.btnQuanLyCauHoi.Size = new System.Drawing.Size(231, 47);
            this.btnQuanLyCauHoi.TabIndex = 3;
            this.btnQuanLyCauHoi.Text = "Quản Lý Câu Hỏi ";
            this.btnQuanLyCauHoi.UseVisualStyleBackColor = true;
            this.btnQuanLyCauHoi.Click += new System.EventHandler(this.btnQuanLyCauHoi_Click);
            // 
            // btnDangXuat
            // 
            this.btnDangXuat.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnDangXuat.Location = new System.Drawing.Point(34, 510);
            this.btnDangXuat.Name = "btnDangXuat";
            this.btnDangXuat.Size = new System.Drawing.Size(231, 49);
            this.btnDangXuat.TabIndex = 4;
            this.btnDangXuat.Text = "Đăng Xuất";
            this.btnDangXuat.UseVisualStyleBackColor = true;
            this.btnDangXuat.Click += new System.EventHandler(this.btnDangXuat_Click);
            // 
            // btnXemThongTinGiaoVien
            // 
            this.btnXemThongTinGiaoVien.Controls.Add(this.btnDoiMatKhau);
            this.btnXemThongTinGiaoVien.Controls.Add(this.button1);
            this.btnXemThongTinGiaoVien.Controls.Add(this.btnDangXuat);
            this.btnXemThongTinGiaoVien.Controls.Add(this.btnQuanLyHocSinh);
            this.btnXemThongTinGiaoVien.Controls.Add(this.btnQuanLyBaiThi);
            this.btnXemThongTinGiaoVien.Controls.Add(this.btnQuanLyCauHoi);
            this.btnXemThongTinGiaoVien.Controls.Add(this.button2);
            this.btnXemThongTinGiaoVien.Location = new System.Drawing.Point(6, 4);
            this.btnXemThongTinGiaoVien.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnXemThongTinGiaoVien.Name = "btnXemThongTinGiaoVien";
            this.btnXemThongTinGiaoVien.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnXemThongTinGiaoVien.Size = new System.Drawing.Size(287, 584);
            this.btnXemThongTinGiaoVien.TabIndex = 5;
            this.btnXemThongTinGiaoVien.TabStop = false;
            this.btnXemThongTinGiaoVien.Text = "Giáo Viên";
            this.btnXemThongTinGiaoVien.Enter += new System.EventHandler(this.btnXemThongTinGiaoVien_Enter);
            // 
            // btnDoiMatKhau
            // 
            this.btnDoiMatKhau.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.btnDoiMatKhau.Location = new System.Drawing.Point(34, 437);
            this.btnDoiMatKhau.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnDoiMatKhau.Name = "btnDoiMatKhau";
            this.btnDoiMatKhau.Size = new System.Drawing.Size(231, 47);
            this.btnDoiMatKhau.TabIndex = 7;
            this.btnDoiMatKhau.Text = "Đổi Mật Khẩu";
            this.btnDoiMatKhau.UseVisualStyleBackColor = true;
            this.btnDoiMatKhau.Click += new System.EventHandler(this.btnDoiMatKhau_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button2.Location = new System.Drawing.Point(34, 31);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(231, 47);
            this.button2.TabIndex = 6;
            this.button2.Text = "Xem Thông Tin Giáo Viên";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.button1.Location = new System.Drawing.Point(34, 360);
            this.button1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(231, 47);
            this.button1.TabIndex = 5;
            this.button1.Text = "Quản Lý Điểm Thi Học Sinh";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Location = new System.Drawing.Point(298, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(839, 584);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            // 
            // FormGiaoVienDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1143, 590);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnXemThongTinGiaoVien);
            this.IsMdiContainer = true;
            this.Name = "FormGiaoVienDashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Giáo Viên";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormGiaoVienDashboard_Load);
            this.btnXemThongTinGiaoVien.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnQuanLyHocSinh;
        private System.Windows.Forms.Button btnQuanLyBaiThi;
        private System.Windows.Forms.Button btnQuanLyCauHoi;
        private System.Windows.Forms.Button btnDangXuat;
        private System.Windows.Forms.GroupBox btnXemThongTinGiaoVien;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button btnDoiMatKhau;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

