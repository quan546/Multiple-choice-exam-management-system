﻿namespace LamBaiThi
{
    internal class CauHoi
    {
        public string DapAnDung { get; internal set; }
        public string MaCauHoi { get; internal set; }
        public string NoiDung { get; internal set; }
        public string DapAnSai1 { get; internal set; }
        public string DapAnSai2 { get; internal set; }
        public string DapAnSai3 { get; internal set; }
    }
}