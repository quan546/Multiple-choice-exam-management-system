﻿namespace LamBaiThi
{
    partial class FormLamBaiThi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblCauHoi = new System.Windows.Forms.Label();
            this.btnCauHoiTruoc = new System.Windows.Forms.Button();
            this.btnCauHoiSau = new System.Windows.Forms.Button();
            this.btnNopBai = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lblThoiGian = new System.Windows.Forms.Label();
            this.lblMaBaiThi = new System.Windows.Forms.Label();
            this.labelMaHocSinh = new System.Windows.Forms.Label();
            this.chkDapAn1 = new System.Windows.Forms.CheckBox();
            this.chkDapAn2 = new System.Windows.Forms.CheckBox();
            this.chkDapAn3 = new System.Windows.Forms.CheckBox();
            this.chkDapAn4 = new System.Windows.Forms.CheckBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCauHoi
            // 
            this.lblCauHoi.AutoSize = true;
            this.lblCauHoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.lblCauHoi.Location = new System.Drawing.Point(90, 100);
            this.lblCauHoi.Name = "lblCauHoi";
            this.lblCauHoi.Size = new System.Drawing.Size(70, 26);
            this.lblCauHoi.TabIndex = 0;
            this.lblCauHoi.Text = "label1";
            // 
            // btnCauHoiTruoc
            // 
            this.btnCauHoiTruoc.Location = new System.Drawing.Point(95, 318);
            this.btnCauHoiTruoc.Name = "btnCauHoiTruoc";
            this.btnCauHoiTruoc.Size = new System.Drawing.Size(112, 36);
            this.btnCauHoiTruoc.TabIndex = 5;
            this.btnCauHoiTruoc.Text = "Câu Hỏi Trước";
            this.btnCauHoiTruoc.UseVisualStyleBackColor = true;
            this.btnCauHoiTruoc.Click += new System.EventHandler(this.btnCauHoiTruoc_Click_1);
            // 
            // btnCauHoiSau
            // 
            this.btnCauHoiSau.Location = new System.Drawing.Point(268, 318);
            this.btnCauHoiSau.Name = "btnCauHoiSau";
            this.btnCauHoiSau.Size = new System.Drawing.Size(119, 36);
            this.btnCauHoiSau.TabIndex = 6;
            this.btnCauHoiSau.Text = "Câu Hỏi Sau";
            this.btnCauHoiSau.UseVisualStyleBackColor = true;
            this.btnCauHoiSau.Click += new System.EventHandler(this.btnCauHoiSau_Click);
            // 
            // btnNopBai
            // 
            this.btnNopBai.Location = new System.Drawing.Point(725, 467);
            this.btnNopBai.Name = "btnNopBai";
            this.btnNopBai.Size = new System.Drawing.Size(106, 36);
            this.btnNopBai.TabIndex = 7;
            this.btnNopBai.Text = "Nộp Bài";
            this.btnNopBai.UseVisualStyleBackColor = true;
            this.btnNopBai.Click += new System.EventHandler(this.btnNopBai_Click_1);
            // 
            // lblThoiGian
            // 
            this.lblThoiGian.AutoSize = true;
            this.lblThoiGian.Location = new System.Drawing.Point(707, 34);
            this.lblThoiGian.Name = "lblThoiGian";
            this.lblThoiGian.Size = new System.Drawing.Size(0, 13);
            this.lblThoiGian.TabIndex = 9;
            // 
            // lblMaBaiThi
            // 
            this.lblMaBaiThi.AutoSize = true;
            this.lblMaBaiThi.Location = new System.Drawing.Point(41, 34);
            this.lblMaBaiThi.Name = "lblMaBaiThi";
            this.lblMaBaiThi.Size = new System.Drawing.Size(35, 13);
            this.lblMaBaiThi.TabIndex = 10;
            this.lblMaBaiThi.Text = "label1";
            this.lblMaBaiThi.Click += new System.EventHandler(this.lblMaBaiThi_Click);
            // 
            // labelMaHocSinh
            // 
            this.labelMaHocSinh.AutoSize = true;
            this.labelMaHocSinh.Location = new System.Drawing.Point(41, 496);
            this.labelMaHocSinh.Name = "labelMaHocSinh";
            this.labelMaHocSinh.Size = new System.Drawing.Size(35, 13);
            this.labelMaHocSinh.TabIndex = 11;
            this.labelMaHocSinh.Text = "label1";
            // 
            // chkDapAn1
            // 
            this.chkDapAn1.AutoSize = true;
            this.chkDapAn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.chkDapAn1.Location = new System.Drawing.Point(95, 184);
            this.chkDapAn1.Name = "chkDapAn1";
            this.chkDapAn1.Size = new System.Drawing.Size(138, 30);
            this.chkDapAn1.TabIndex = 12;
            this.chkDapAn1.Text = "checkBox1";
            this.chkDapAn1.UseVisualStyleBackColor = true;
            // 
            // chkDapAn2
            // 
            this.chkDapAn2.AutoSize = true;
            this.chkDapAn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.chkDapAn2.Location = new System.Drawing.Point(268, 184);
            this.chkDapAn2.Name = "chkDapAn2";
            this.chkDapAn2.Size = new System.Drawing.Size(138, 30);
            this.chkDapAn2.TabIndex = 13;
            this.chkDapAn2.Text = "checkBox2";
            this.chkDapAn2.UseVisualStyleBackColor = true;
            // 
            // chkDapAn3
            // 
            this.chkDapAn3.AutoSize = true;
            this.chkDapAn3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.chkDapAn3.Location = new System.Drawing.Point(449, 184);
            this.chkDapAn3.Name = "chkDapAn3";
            this.chkDapAn3.Size = new System.Drawing.Size(138, 30);
            this.chkDapAn3.TabIndex = 14;
            this.chkDapAn3.Text = "checkBox3";
            this.chkDapAn3.UseVisualStyleBackColor = true;
            // 
            // chkDapAn4
            // 
            this.chkDapAn4.AutoSize = true;
            this.chkDapAn4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.125F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(163)));
            this.chkDapAn4.Location = new System.Drawing.Point(679, 184);
            this.chkDapAn4.Name = "chkDapAn4";
            this.chkDapAn4.Size = new System.Drawing.Size(138, 30);
            this.chkDapAn4.TabIndex = 15;
            this.chkDapAn4.Text = "checkBox4";
            this.chkDapAn4.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.chkDapAn4);
            this.groupBox1.Controls.Add(this.chkDapAn1);
            this.groupBox1.Controls.Add(this.chkDapAn3);
            this.groupBox1.Controls.Add(this.btnNopBai);
            this.groupBox1.Controls.Add(this.chkDapAn2);
            this.groupBox1.Controls.Add(this.btnCauHoiSau);
            this.groupBox1.Controls.Add(this.lblCauHoi);
            this.groupBox1.Controls.Add(this.btnCauHoiTruoc);
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2);
            this.groupBox1.Size = new System.Drawing.Size(872, 554);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Làm Bài Thi";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // FormLamBaiThi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(884, 552);
            this.Controls.Add(this.labelMaHocSinh);
            this.Controls.Add(this.lblMaBaiThi);
            this.Controls.Add(this.lblThoiGian);
            this.Controls.Add(this.groupBox1);
            this.Name = "FormLamBaiThi";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Làm Bài Thi";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FormLamBaiThi_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCauHoi;
        private System.Windows.Forms.Button btnCauHoiTruoc;
        private System.Windows.Forms.Button btnCauHoiSau;
        private System.Windows.Forms.Button btnNopBai;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lblThoiGian;
        private System.Windows.Forms.Label lblMaBaiThi;
        private System.Windows.Forms.Label labelMaHocSinh;
        private System.Windows.Forms.CheckBox chkDapAn1;
        private System.Windows.Forms.CheckBox chkDapAn2;
        private System.Windows.Forms.CheckBox chkDapAn3;
        private System.Windows.Forms.CheckBox chkDapAn4;
        private System.Windows.Forms.GroupBox groupBox1;
    }
}

