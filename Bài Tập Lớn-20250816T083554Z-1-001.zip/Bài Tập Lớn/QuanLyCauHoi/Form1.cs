﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyCauHoi
{
    public partial class FormQuanLyCauHoi : Form
    {
        public FormQuanLyCauHoi()
        {
            InitializeComponent();
        }

        private void btnThemCauHoi_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString))
            {

                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_ThemCauHoi", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaCauHoi", txtMaCauHoi.Text);
                cmd.Parameters.AddWithValue("@NoiDung", txtNoiDung.Text);
                cmd.Parameters.AddWithValue("@DoKho", txtDoKho.Text);
                cmd.Parameters.AddWithValue("@DapAnDung", txtDapAnDung.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Thêm câu hỏi thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                HienThiDanhSach();

            }
        }
        private void HienThiDanhSach()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("sp_HienThiDanhSach", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvDanhSach.DataSource = dt;
                }

            }
        }

        private void btnSuaCauHoi_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_SuaCauHoi", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaCauHoi", txtMaCauHoi.Text);
                cmd.Parameters.AddWithValue("@NoiDung", txtNoiDung.Text);
                cmd.Parameters.AddWithValue("@DoKho", txtDoKho.Text);
                cmd.Parameters.AddWithValue("@DapAnDung", txtDapAnDung.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Cập nhật câu hỏi thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                HienThiDanhSach();

            }
        }

        private void btnXoaCauHoi_Click(object sender, EventArgs e)
        {
            if (dgvDanhSach.SelectedRows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn câu hỏi cần xóa!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string maCauHoi = dgvDanhSach.SelectedRows[0].Cells["MaCauHoi"].Value.ToString();

            DialogResult result = MessageBox.Show($"Bạn có chắc chắn muốn xóa câu hỏi \"{maCauHoi}\" không?",
                                                  "Xác nhận xóa",
                                                  MessageBoxButtons.YesNo,
                                                  MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand("sp_XoaCauHoi", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@MaCauHoi", maCauHoi);

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Xóa câu hỏi thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    HienThiDanhSach();

                }
            }
        }

        private void btnHienThiChiTietBaiThi_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("sp_HienCauHoi", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvDanhSach.DataSource = dt;
                    DinhDangDataGridView();
                }

            }
        }

        private void btnHienThiCauHoi_Click(object sender, EventArgs e)
        {

        }

        private void FormQuanLyCauHoi_Load(object sender, EventArgs e)
        {

        }

        private void btnTimKiemCauHoi_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {

                conn.Open();
                string query = "SELECT * FROM tblCauHoi WHERE 1=1";
                List<SqlParameter> parameters = new List<SqlParameter>();

                if (!string.IsNullOrWhiteSpace(txtMaCauHoi.Text))
                {
                    query += " AND MaCauHoi LIKE @MaCauHoi";
                    parameters.Add(new SqlParameter("@MaCauHoi", "%" + txtMaCauHoi.Text + "%"));
                }

                if (!string.IsNullOrWhiteSpace(txtNoiDung.Text))
                {
                    query += " AND NoiDung LIKE @NoiDung";
                    parameters.Add(new SqlParameter("@NoiDung", "%" + txtNoiDung.Text + "%"));
                }

                if (!string.IsNullOrWhiteSpace(txtDoKho.Text))
                {
                    query += " AND DoKho = @DoKho";
                    parameters.Add(new SqlParameter("@DoKho", txtDoKho.Text));
                }

                if (!string.IsNullOrWhiteSpace(txtDapAnDung.Text))
                {
                    query += " AND DapAnDung = @DapAnDung";
                    parameters.Add(new SqlParameter("@DapAnDung", txtDapAnDung.Text));
                }

                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                foreach (var param in parameters)
                {
                    da.SelectCommand.Parameters.Add(param);
                }

                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvDanhSach.DataSource = dt;

            }
        }

        private void dgvDanhSach_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = dgvDanhSach.Rows[e.RowIndex];

                // Kiểm tra xem đang hiển thị danh sách câu hỏi hay bài thi
                if (dgvDanhSach.Columns.Contains("MaCauHoi"))
                {
                    // Đang hiển thị câu hỏi -> Điền thông tin câu hỏi
                    txtMaCauHoi.Text = row.Cells["MaCauHoi"].Value.ToString();
                    txtNoiDung.Text = row.Cells["NoiDung"].Value.ToString();
                    txtDoKho.Text = row.Cells["DoKho"].Value.ToString();
                    txtDapAnDung.Text = row.Cells["DapAnDung"].Value.ToString();

                    // Xóa dữ liệu bài thi nếu đang có
                    txtMaBaiThi.Clear();
                }
                else if (dgvDanhSach.Columns.Contains("MaBaiThi"))
                {
                    // Đang hiển thị bài thi -> Điền thông tin bài thi
                    txtMaBaiThi.Text = row.Cells["MaBaiThi"].Value.ToString();

                    // Xóa dữ liệu câu hỏi nếu đang có
                    txtMaCauHoi.Clear();
                    txtNoiDung.Clear();
                    txtDoKho.Clear();
                    txtDapAnDung.Clear();
                }
            }
        }
        private void DinhDangDataGridView()
        {

            dgvDanhSach.Columns["MaCauHoi"].HeaderText = "Mã Câu Hỏi";
            dgvDanhSach.Columns["NoiDung"].HeaderText = "Nội Dung Câu Hỏi";
            dgvDanhSach.Columns["DoKho"].HeaderText = "Độ Khó";
            dgvDanhSach.Columns["DapAnDung"].HeaderText = "Đáp Án Đúng";
            if (dgvDanhSach.Columns.Contains("MaBaiThi"))
            {
                dgvDanhSach.Columns["MaBaiThi"].HeaderText = "Mã Bài Thi";
            }

            dgvDanhSach.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDanhSach.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDanhSach.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }


        private void btnHienThiChiTiet_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaBaiThi.Text))
            {
                MessageBox.Show("Vui lòng nhập Mã Bài Thi!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString))
            {

                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_HienThiChiTietBaiThi", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaBaiThi", txtMaBaiThi.Text);

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvDanhSach.DataSource = dt;
                DinhDangDataGridView();

                if (dt.Rows.Count == 0)
                {
                    MessageBox.Show("Không tìm thấy bài thi hoặc bài thi chưa có câu hỏi!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

            }
        }

        private void btnThemVaoBaiThi_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaBaiThi.Text) || string.IsNullOrWhiteSpace(txtMaCauHoi.Text))
            {
                toolStripStatusLabel1.Text = "Vui lòng nhập Mã Bài Thi và Mã Câu Hỏi";
                Task.Delay(3000).ContinueWith(_ => toolStripStatusLabel1.Text = ""); // Ẩn sau 3 giây
                return;
            }

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_ThemCauHoiVaoBaiThi", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaBaiThi", txtMaBaiThi.Text);
                cmd.Parameters.AddWithValue("@MaCauHoi", txtMaCauHoi.Text);

                cmd.ExecuteNonQuery();

                toolStripStatusLabel1.Text = "Thêm câu hỏi vào bài thi thành công";
                Task.Delay(3000).ContinueWith(_ => toolStripStatusLabel1.Text = ""); // Ẩn sau 3 giây
                HienThiDanhSach();
            }


        }

        private void btnXoaKhoiBaiThi_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaBaiThi.Text) || string.IsNullOrWhiteSpace(txtMaCauHoi.Text))
            {
                MessageBox.Show("Vui lòng nhập Mã Bài Thi và Mã Câu Hỏi!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection conn = new SqlConnection(ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("sp_XoaCauHoiKhoiBaiThi", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MaBaiThi", txtMaBaiThi.Text);
                cmd.Parameters.AddWithValue("@MaCauHoi", txtMaCauHoi.Text);

                cmd.ExecuteNonQuery();
                MessageBox.Show("Xóa câu hỏi khỏi bài thi thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                HienThiDanhSach();
            }


        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void btnDong_Click(object sender, EventArgs e)
        {
            DialogResult xacnhan = MessageBox.Show("Bạn có chắc chắn muốn thoát không? ", "Thông Báo", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (xacnhan == DialogResult.Yes)
            {
                Close();
            }
        }
    }
}

