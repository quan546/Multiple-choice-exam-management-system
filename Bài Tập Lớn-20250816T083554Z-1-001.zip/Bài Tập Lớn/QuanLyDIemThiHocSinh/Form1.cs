﻿
using ReportBangDiemCuaMotLopHoc;
using ReportDiemThiHocSinhCaTruong;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyDIemThiHocSinh
{
    public partial class FormQuanLyDIemThi : Form
    {
        public FormQuanLyDIemThi()
        {
            InitializeComponent();
        }

        private void LoadDiemThi()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                        SELECT dt.MaHS, hs.HoTen, hs.MaLop, dt.MaBaiThi, dt.Diem, dt.NgayThi, 
                               CONVERT(DATE, dt.NgayCham) AS NgayCham 
                        FROM tblDiemThi dt 
                        JOIN tblHocSinh hs ON dt.MaHS = hs.MaHS";

                    SqlDataAdapter da = new SqlDataAdapter(query, conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvDiemThi.DataSource = dt;
                    DinhDangDataGridView();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi tải danh sách điểm thi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadDiemThi();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            DialogResult dia = MessageBox.Show("Bạn có chắc chắc muốn thoát không ?", "Thông báo", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            if (dia == DialogResult.Yes)
            {
                Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            string connectionString = ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand("sp_XoaDiemThi", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        DialogResult xacnhanxoadiemthi = MessageBox.Show("Bạn có chắc chắn muốn xóa bài thi " + txtMaBaiThi.Text + "của học sinh " + txtMaHocSinh.Text, "Thông báo" , MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
                        if (xacnhanxoadiemthi == DialogResult.Yes)
                        {
                            cmd.Parameters.Add("@MaHS", SqlDbType.NVarChar, 10).Value = txtMaHocSinh.Text;
                            cmd.Parameters.Add("@MaBaiThi", SqlDbType.NVarChar, 10).Value = txtMaBaiThi.Text;

                            // Thực thi Stored Procedure và lấy số dòng bị xóa
                            int rowsAffected = Convert.ToInt32(cmd.ExecuteScalar());

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Xóa điểm thi thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                LoadDiemThi(); // Cập nhật lại danh sách điểm thi
                            }
                            else
                            {
                                MessageBox.Show("Không tìm thấy điểm thi để xóa!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi xóa điểm thi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dgvDiemThi.SelectedRows.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn điểm thi cần cập nhật!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string maHS = dgvDiemThi.SelectedRows[0].Cells["MaHS"].Value.ToString();
            string maBaiThi = dgvDiemThi.SelectedRows[0].Cells["MaBaiThi"].Value.ToString();
            double diemMoi;

            if (!double.TryParse(txtDiemThi.Text, out diemMoi) || diemMoi < 0 || diemMoi > 10)
            {
                MessageBox.Show("Điểm phải nằm trong khoảng từ 0 đến 10!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                string query = "UPDATE tblDiemThi SET Diem = @Diem WHERE MaHS = @MaHS AND MaBaiThi = @MaBaiThi";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Diem", diemMoi);
                    cmd.Parameters.AddWithValue("@MaHS", maHS);
                    cmd.Parameters.AddWithValue("@MaBaiThi", maBaiThi);

                    cmd.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Cập nhật điểm thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadDiemThi();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString;

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("sp_TimKiemDiemThi", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    // Thêm tham số, nếu giá trị trống thì gửi NULL
                    cmd.Parameters.AddWithValue("@MaHS", string.IsNullOrWhiteSpace(txtMaHocSinh.Text) ? (object)DBNull.Value : txtMaHocSinh.Text);
                    cmd.Parameters.AddWithValue("@MaLop", string.IsNullOrWhiteSpace(txtMaLop.Text) ? (object)DBNull.Value : txtMaLop.Text);
                    cmd.Parameters.AddWithValue("@MaBaiThi", string.IsNullOrWhiteSpace(txtMaBaiThi.Text) ? (object)DBNull.Value : txtMaBaiThi.Text);

                    if (string.IsNullOrWhiteSpace(txtDiemThi.Text))
                        cmd.Parameters.AddWithValue("@Diem", DBNull.Value);
                    else
                        cmd.Parameters.AddWithValue("@Diem", float.Parse(txtDiemThi.Text));

                    if (dtpNgayCham.Value == null)
                        cmd.Parameters.AddWithValue("@NgayCham", DBNull.Value);
                    else
                        cmd.Parameters.AddWithValue("@NgayCham", dtpNgayCham.Value.Date);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvDiemThi.DataSource = dt; // Hiển thị dữ liệu lên DataGridView
                }
            }
        }

        private void dgvDiemThi_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Đảm bảo không click vào tiêu đề cột
            {
                DataGridViewRow row = dgvDiemThi.Rows[e.RowIndex];

                // Hiển thị dữ liệu lên các TextBox
                txtMaHocSinh.Text = row.Cells["MaHS"].Value?.ToString();
                txtHoTenHocSinh.Text = row.Cells["HoTen"].Value?.ToString();
                txtMaLop.Text = row.Cells["MaLop"].Value?.ToString();
                txtMaBaiThi.Text = row.Cells["MaBaiThi"].Value?.ToString();
                txtDiemThi.Text = row.Cells["Diem"].Value?.ToString();
                dtpNgayThi.Value = Convert.ToDateTime(row.Cells["NgayThi"].Value);


                // Kiểm tra nếu có Ngày Chấm thì hiển thị, ngược lại bỏ chọn
                if (row.Cells["NgayCham"].Value != DBNull.Value && row.Cells["NgayCham"].Value != null)
                {
                    dtpNgayCham.Value = Convert.ToDateTime(row.Cells["NgayCham"].Value);
                    dtpNgayCham.Checked = true; // Đánh dấu đã chọn
                }
                else
                {
                    dtpNgayCham.Checked = false; // Bỏ chọn nếu không có ngày chấm
                }
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            RpDiemThiHocSinhCaTruong rpdiemthicatruong = new RpDiemThiHocSinhCaTruong();
            this.Hide();
            rpdiemthicatruong.ShowDialog();
            this.Show();

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtMaLop.Text))
            {
                MessageBox.Show("Vui lòng nhập mã lớp!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string maLop = txtMaLop.Text.Trim(); // Lấy giá trị mã lớp từ TextBox

            FormReportBangDiem1LopHoc rpbangdiem1lophoc = new FormReportBangDiem1LopHoc(maLop);
            this.Hide();
            rpbangdiem1lophoc.ShowDialog();
            this.Show();
        }
        private void DinhDangDataGridView()
        {
            dgvDiemThi.Columns["MaBaiThi"].HeaderText = "Mã Bài Thi";
            dgvDiemThi.Columns["HoTen"].HeaderText = "Họ Tên";
            dgvDiemThi.Columns["MaHS"].HeaderText = "Mã Hoc Sinh";
            dgvDiemThi.Columns["Diem"].HeaderText = "Điểm Thi";
            dgvDiemThi.Columns["NgayCham"].HeaderText = "Ngày Chấm";
            dgvDiemThi.Columns["NgayThi"].HeaderText = "Ngày Thi";
            dgvDiemThi.Columns["MaLop"].HeaderText = "Mã Lớp";

            dgvDiemThi.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvDiemThi.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dgvDiemThi.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }
    }
}
