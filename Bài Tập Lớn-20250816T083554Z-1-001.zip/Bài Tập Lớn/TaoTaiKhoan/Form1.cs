﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaoTaiKhoan
{
    public partial class FormTaoTaiKhoan : Form
    {
        public FormTaoTaiKhoan()
        {
            InitializeComponent();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void FormTaoTaiKhoan_Load(object sender, EventArgs e)
        {
            cbLoaiTaiKhoan.Items.Add("Học sinh");
            cbLoaiTaiKhoan.Items.Add("Giáo viên");
            cbLoaiTaiKhoan.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string tendangnhap = txtTenDangNhap.Text.Trim();
            string matkhau = txtMatKhau.Text.Trim();
            string malienket = txtMaLienKet.Text.Trim();
            string mataikhoan = txtMaTaiKhoan.Text.Trim();
            string loaitaikhoan = cbLoaiTaiKhoan.SelectedItem.ToString(); 


            if (string.IsNullOrWhiteSpace(tendangnhap) || string.IsNullOrWhiteSpace(matkhau) || string.IsNullOrWhiteSpace(malienket))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string connectionString = ConfigurationManager.ConnectionStrings["QuanLyThiTracNghiem"].ConnectionString;
            // Kiểm tra mật khẩu có đu điều kiện không 
            if (!KiemTraMatKhau(matkhau))
            {
                MessageBox.Show("Mật khẩu phải có ít nhất 1 kí tự thường, in hoa, số và kí tự đặc biệt", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand("sp_TaoTaiKhoan", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@TenDangNhap", tendangnhap);
                        cmd.Parameters.AddWithValue("@MatKhau", matkhau);
                        cmd.Parameters.AddWithValue("@LoaiTaiKhoan", loaitaikhoan); 
                        cmd.Parameters.AddWithValue("@MaLienKet", malienket);
                        cmd.Parameters.AddWithValue("@MaTaiKhoan", mataikhoan);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Tạo tài khoản thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            this.Close();
                        }
                        else
                        {
                            MessageBox.Show("Tạo tài khoản thất bại! Kiểm tra lại thông tin.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi SQL: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }
        private bool KiemTraMatKhau(string matKhau)
        {
            string pattern = @"^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[\W_]).{8,}$"; // tói thiểu có 8 kí tự bao gồm kí tự đặc biệt, có kí tự in hoa, kí tự thường, kí tự đặc biệt và số
            return Regex.IsMatch(matKhau, pattern);
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
